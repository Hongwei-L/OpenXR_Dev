﻿// 2DLauncher_Config.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "launcher_config.h"

int main()
{
	ApplicationInformation app_added = { 2,1,TEXT("test_application_name"), TEXT("c:\\tmp\\test_application_name.exe"), TEXT(""), TEXT("test_application_name") };
	ApplicationInformation app[10];
	int app_number = 10;

	launcher_config::Instance()->read_applications_config(nullptr, app_number);
	printf("app_number = %d\n", app_number);
	launcher_config::Instance()->read_applications_config(app, app_number);
	wprintf(TEXT("will delete %s\n"), app[app_number - 1].key_name);
	launcher_config::Instance()->append_application_config(&app_added);
	//launcher_config::Instance()->delete_application_config(app[app_number - 1].key_name);
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
