﻿#include <windows.h>
#include <wchar.h>
#include <stdio.h>
#include <string.h>
#include "launcher_config.h"

#define KEY_PATH	TEXT("SOFTWARE\\WOW6432Node\\Lenovo\\LXR")

launcher_config* launcher_config::conf = nullptr;

bool launcher_config::read_applications_config(ApplicationInformation* application_list, int& application_number)
{
	HKEY key_handle = nullptr;
	int  sub_key_number = 0;
	bool ret = true;

	key_handle = open_lxr_registe_entry(KEY_READ);
	if (key_handle == nullptr)
	{
		printf("failed open_lxr_registe_entry\n");
		return false;
	}

	sub_key_number = get_applications_number(key_handle);
	if (application_list == nullptr || sub_key_number > application_number)
	{
		application_number = sub_key_number;
		close_lxr_registe_entry(key_handle);
		return false;
	}

	sub_key_number = load_all_applications_information(key_handle, application_list, sub_key_number);
	if (sub_key_number == -1)
	{
		application_number = -1;
		ret = false;
	}

	close_lxr_registe_entry(key_handle);

	return ret;
}

bool launcher_config::delete_application_config(const TCHAR* application_name)
{
	HKEY key_handle = nullptr;
	int  sub_key_number = 0;
	bool ret = true;

	key_handle = open_lxr_registe_entry(KEY_WRITE | KEY_READ);
	if (key_handle == nullptr)
	{
		printf("failed open_lxr_registe_entry\n");
		return false;
	}

	return del_application_information(key_handle, application_name);
}

bool launcher_config::append_application_config(const ApplicationInformation* app)
{
	HKEY key_handle = nullptr;
	TCHAR sub_key_path[MAX_PATH];
	DWORD option = REG_OPTION_NON_VOLATILE;
	DWORD description;
	DWORD write_length;
	bool ret = true;

	if (app == nullptr)
	{
		return false;
	}

	swprintf_s(sub_key_path, MAX_PATH, TEXT("%s\\%s"), KEY_PATH, app->key_name);

	//delete the target key first
	delete_application_config(app->key_name);

	//create the key
	if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, sub_key_path, 0, nullptr, option, KEY_WRITE, nullptr, &key_handle, &description) != ERROR_SUCCESS)
	{
		return false;
	}

	write_length = wcslen(app->application_name) * 2;
	if (RegSetValueEx(key_handle, TEXT("application_name"), 0, REG_SZ, (BYTE*)app->application_name, write_length) != ERROR_SUCCESS)
	{
		goto failed;
	}

	write_length = wcslen(app->excutable_file_name) * 2;
	if (RegSetValueEx(key_handle, TEXT("excutable_file_name"), 0, REG_SZ, (BYTE*)app->excutable_file_name, write_length) != ERROR_SUCCESS)
	{
		goto failed;
	}

	write_length = wcslen(app->invoke_param) * 2;
	if (RegSetValueEx(key_handle, TEXT("invoke_param"), 0, REG_SZ, (BYTE*)app->invoke_param, write_length) != ERROR_SUCCESS)
	{
		goto failed;
	}

	write_length = sizeof(app->version_max);
	if (RegSetValueEx(key_handle, TEXT("version_max"), 0, REG_DWORD, (BYTE*)&app->version_max, write_length) != ERROR_SUCCESS)
	{
		goto failed;
	}

	write_length = sizeof(app->version_min);
	if (RegSetValueEx(key_handle, TEXT("version_min"), 0, REG_DWORD, (BYTE*)&app->version_min, write_length) != ERROR_SUCCESS)
	{
		goto failed;
	}

	RegCloseKey(key_handle);

	return true;

failed:
	RegCloseKey(key_handle);

	//recover the created key
	delete_application_config(app->key_name);

	return false;
}





HKEY launcher_config::open_lxr_registe_entry(DWORD access_type)
{
	HKEY hKey;

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, KEY_PATH, 0, access_type, &hKey) != ERROR_SUCCESS)
	{
		//failed to open the registe
		return nullptr;
	}

	return hKey;
}

void launcher_config::close_lxr_registe_entry(HKEY key_handle)
{
	if (key_handle != nullptr)
	{
		RegCloseKey(key_handle);
	}
}

int launcher_config::get_applications_number(HKEY key_handle)
{
	DWORD retCode;
	TCHAR class_name[MAX_PATH];
	DWORD class_name_length = MAX_PATH;
	DWORD sub_key_number = 0;
	DWORD sub_key_size = 0;
	DWORD sub_key_length = 0;
	FILETIME last_modify_time = { 0 };

	//query the key information 
	retCode = RegQueryInfoKey(key_handle,
		class_name, &class_name_length, nullptr,
		&sub_key_number, &sub_key_size, &sub_key_length,
		nullptr, nullptr, nullptr,
		nullptr, &last_modify_time);
	if (retCode != ERROR_SUCCESS)
	{
		return -1;
	}

	return sub_key_number;
}

int launcher_config::load_all_applications_information(HKEY key_handle, ApplicationInformation* application_list, int application_number)
{
	FILETIME last_modify_time = { 0 };
	TCHAR sub_key_name[MAX_PATH];
	DWORD sub_key_name_length = MAX_PATH;
	DWORD valid_sub_key_number = 0;
	TCHAR sub_key_full_name[MAX_PATH];
	bool  ret = false;
	ApplicationInformation* app_list = application_list;
	int   valid_application_number = 0;
	DWORD retCode = 0;

	for (valid_sub_key_number = 0; valid_sub_key_number < application_number; valid_sub_key_number++)
	{
		sub_key_name_length = MAX_PATH;
		memset(sub_key_name, 0, sizeof(sub_key_name));
		retCode = RegEnumKeyEx(key_handle, valid_sub_key_number, sub_key_name, &sub_key_name_length, nullptr, nullptr, nullptr, &last_modify_time);
		if (retCode != ERROR_SUCCESS)
		{
			break;
		}
		wcscpy_s(app_list->key_name, MAX_PATH, sub_key_name);
		memset(&sub_key_full_name, 0, sizeof(sub_key_full_name));
		swprintf_s(sub_key_full_name, TEXT("%s\\%s"), KEY_PATH, sub_key_name);

		if (load_special_application_information(sub_key_full_name, app_list))
		{
			app_list++;
			valid_application_number++;
		}
	}

	return valid_application_number;
}

bool launcher_config::load_special_application_information(const TCHAR* key_path, ApplicationInformation* app)
{
	HKEY application_key = nullptr;
	DWORD data_type;
	DWORD data_value;
	DWORD data_length;
	TCHAR string_value[MAX_PATH];
	bool  ret = false;

	if (key_path == nullptr || app == nullptr)
	{
		return false;
	}

	//open the key
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, key_path, 0, KEY_READ, &application_key) != ERROR_SUCCESS)
	{
		//failed to open the registe
		return false;
	}

	//start to read the application config
	data_type = REG_DWORD;
	data_length = sizeof(data_length);
	if (RegQueryValueEx(application_key, TEXT("version_max"), nullptr, &data_type, (BYTE*)&data_value, &data_length) != ERROR_SUCCESS)
	{
		goto out;
	}
	app->version_max = data_value;

	data_type = REG_DWORD;
	data_length = sizeof(data_length);
	if (RegQueryValueEx(application_key, TEXT("version_min"), nullptr, &data_type, (BYTE*)&data_value, &data_length) != ERROR_SUCCESS)
	{
		goto out;
	}
	app->version_min = data_value;

	data_type = REG_SZ;
	data_length = MAX_PATH;
	if (RegQueryValueEx(application_key, TEXT("application_name"), nullptr, &data_type, (BYTE*)string_value, &data_length) != ERROR_SUCCESS)
	{
		goto out;
	}
	wcscpy_s(app->application_name, sizeof(app->application_name) / 2, string_value);

	data_type = REG_SZ;
	data_length = MAX_PATH;
	if (RegQueryValueEx(application_key, TEXT("excutable_file_name"), nullptr, &data_type, (BYTE*)string_value, &data_length) != ERROR_SUCCESS)
	{
		goto out;
	}
	wcscpy_s(app->excutable_file_name, sizeof(app->excutable_file_name) / 2, string_value);


	data_type = REG_SZ;
	data_length = MAX_PATH;
	if (RegQueryValueEx(application_key, TEXT("invoke_param"), nullptr, &data_type, (BYTE*)string_value, &data_length) != ERROR_SUCCESS)
	{
		goto out;
	}
	wcscpy_s(app->invoke_param, sizeof(app->invoke_param) / 2, string_value);

	ret = true;
out:
	if (application_key != nullptr)
	{
		RegCloseKey(application_key);
		application_key = nullptr;
	}

	return ret;
}

bool launcher_config::add_application_information(HKEY key_handle, ApplicationInformation* app)
{
	return true;
}

bool launcher_config::del_application_information(HKEY key_handle, const TCHAR* application_name)
{
	if (RegDeleteKey(key_handle, application_name) == ERROR_SUCCESS)
	{
		return true;
	}
	return false;
}
