﻿#pragma once
#include <windows.h>
#include <winreg.h>


typedef struct {
	unsigned int version_max;
	unsigned int version_min;
	TCHAR application_name[64];
	TCHAR excutable_file_name[MAX_PATH];
	TCHAR invoke_param[MAX_PATH];
	TCHAR key_name[MAX_PATH];
}ApplicationInformation;

typedef struct {
	TCHAR default_application_key[MAX_PATH];

}ConfigInformation;

class launcher_config
{
public:
	~launcher_config()
	{
		if (conf != nullptr)
		{
			delete conf;
			conf = nullptr;
		}
	}

	static launcher_config* Instance()
	{
		if (conf == nullptr)
		{
			conf = new launcher_config();
		}
		return conf;
	};

	bool read_applications_config(ApplicationInformation* application_list, int& application_number);
	bool delete_application_config(const TCHAR* key_name);
	bool append_application_config(const ApplicationInformation* app);
	//void clear_all_application_config();

private:
	launcher_config()
	{
		conf = nullptr;
	};

	static launcher_config* conf;

	HKEY open_lxr_registe_entry(DWORD access_type);
	void close_lxr_registe_entry(HKEY key_handle);

	int  get_applications_number(HKEY key_handle);

	int  load_all_applications_information(HKEY key_handle, ApplicationInformation* application_list, int application_number);
	bool load_special_application_information(const TCHAR* key_path, ApplicationInformation* app);

	bool add_application_information(HKEY key_handle, ApplicationInformation* app);

	bool del_application_information(HKEY key_handle, const TCHAR* application_name);


	bool write_application_config(const TCHAR* key_path, ApplicationInformation* app);
};
